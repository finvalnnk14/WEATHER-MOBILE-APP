class GenerateWeatherNameHelper {
  static final Map<int, String> weatherDescriptions = {
    0: 'Cerah / Clear Skies',
    1: 'Cerah Berawan / Partly Cloudy',
    2: 'Cerah Berawan / Partly Cloudy',
    3: 'Berawan / Mostly Cloudy',
    4: 'Berawan Tebal / Overcast',
    5: 'Udara Kabur / Haze',
    10: 'Asap / Smoke',
    45: 'Kabut / Fog',
    60: 'Hujan Ringan / Light Rain',
    61: 'Hujan Sedang / Rain',
    63: 'Hujan Lebat / Heavy Rain',
    80: 'Hujan Lokal / Isolated Shower',
    95: 'Hujan Petir / Severe Thunderstorm',
    97: 'Hujan Petir / Severe Thunderstorm',
  };

  static String getWeatherDescription(int code) {
    return weatherDescriptions[code] ?? 'Unknown Weather';
  }
}
