// Project imports:
import 'package:opweather/core/routing/weather_routing.dart';

class AppRouting {
  static final routes = [
    ...WeatherRouting.routes,
  ];
}
