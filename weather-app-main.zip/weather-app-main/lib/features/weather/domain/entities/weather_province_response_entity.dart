// Project imports:
import 'package:opweather/features/features.dart';

class WeatherProvinceResponseEntity {
  final List<WeatherProvinceEntity> provinces;

  WeatherProvinceResponseEntity({
    required this.provinces,
  });
}
