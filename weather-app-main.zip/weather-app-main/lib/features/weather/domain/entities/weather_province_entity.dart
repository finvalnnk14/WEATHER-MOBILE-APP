class WeatherProvinceEntity {
  final String id;
  final String name;

  WeatherProvinceEntity({
    required this.id,
    required this.name,
  });
}
