class TimerangeValueEntity {
  final String unit;
  final String text;

  TimerangeValueEntity({
    required this.unit,
    required this.text,
  });
}
